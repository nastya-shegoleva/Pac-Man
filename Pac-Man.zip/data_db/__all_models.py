from . import inf_game
from . import standard_game